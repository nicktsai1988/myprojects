
#include <Windows.h>

BOOL WINAPI _DllMainCRTStartup(HINSTANCE hinstDLL, DWORD fdwReason,
                               LPVOID lpReserved)
{
     return (TRUE);
}
