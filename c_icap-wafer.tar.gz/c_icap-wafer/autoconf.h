/* autoconf.h.  Generated from autoconf.h.in by configure.  */
/* autoconf.h.in.  Generated from configure.in by autoheader.  */

/* Define HAVE_BDB if berkeley DB is installed */
/* #undef HAVE_BDB */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the `inet_aton' function. */
#define HAVE_INET_ATON 1

/* Define HAVE_INTTYPES_H if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define HAVE_IPV6 if OS supports ipv6 */
/* #undef HAVE_IPV6 */

/* Define HAVE_LDAP if LDAP libraries are installed */
/* #undef HAVE_LDAP */

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `mmap' function. */
#define HAVE_MMAP 1

/* Define to 1 if you have the `munmap' function. */
#define HAVE_MUNMAP 1

/* Define to 1 if you have the `nanosleep' function. */
#define HAVE_NANOSLEEP 1

/* Define HAVE_POSIX_FILE_LOCK if posix fcntl file locking works */
#define HAVE_POSIX_FILE_LOCK 1

/* Define HAVE_POSIX_MAPPED_FILES if mmap and munmap exists */
#define HAVE_POSIX_MAPPED_FILES 1

/* Define HAVE_POSIX_SEMAPHORES if posix 1003.1b semaphores works */
#define HAVE_POSIX_SEMAPHORES 1

/* Define HAVE_PTHREADS_RWLOCK if pthreads library supports rwlocks */
#define HAVE_PTHREADS_RWLOCK 1

/* Define HAVE_REGEX if regex.h exists (posix regular expressions - maybe more
   tests needed) */
#define HAVE_REGEX 1

/* Define to 1 if you have the <regex.h> header file. */
#define HAVE_REGEX_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strncasestr' function. */
/* #undef HAVE_STRNCASESTR */

/* Define to 1 if you have the `strnstr' function. */
/* #undef HAVE_STRNSTR */

/* Define HAVE_SYSV_IPC if sys/ipc.h exists (maybe more tests needed) */
#define HAVE_SYSV_IPC 1

/* Define to 1 if you have the <sys/ipc.h> header file. */
#define HAVE_SYS_IPC_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define HAVE_SYS_TYPES_H if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define HAVE_UNION_SEMUN if union semun defined in ipc */
/* #undef HAVE_UNION_SEMUN */

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define HAVE_ZLIB if zlib installed */
#define HAVE_ZLIB 1

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#define LT_OBJDIR ".libs/"

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
/* #undef NO_MINUS_C_MINUS_O */

/* Name of package */
#define PACKAGE "c_icap"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "c_icap"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "c_icap 0.2.5"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "c_icap"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.2.5"

/* The size of `int', as computed by sizeof. */
#define SIZEOF_INT 4

/* The size of `long', as computed by sizeof. */
#define SIZEOF_LONG 8

/* The size of `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8

/* The size of `off_t', as computed by sizeof. */
#define SIZEOF_OFF_T 8

/* The size of `short', as computed by sizeof. */
#define SIZEOF_SHORT 2

/* The size of `void *', as computed by sizeof. */
#define SIZEOF_VOID_P 8

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "0.2.5"

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */
