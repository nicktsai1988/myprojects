/*
 *  Copyright (C) 2004-2008 Christos Tsantilas
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *  MA  02110-1301  USA.
 */

#include "common.h"
#include "c-icap.h"
#include "service.h"
#include "header.h"
#include "body.h"
#include "simple_api.h"
#include "debug.h"
#include <sys/types.h>
#include <signal.h>

#define _GNU_SOURCE
#include<string.h>
int echo_init_service(ci_service_xdata_t * srv_xdata,
                      struct ci_server_conf *server_conf);
int echo_check_preview_handler(char *preview_data, int preview_data_len,
                               ci_request_t *);
int echo_end_of_data_handler(ci_request_t * req);
void *echo_init_request_data(ci_request_t * req);
void echo_close_service();
void echo_release_request_data(void *data);
int echo_io(char *wbuf, int *wlen, char *rbuf, int *rlen, int iseof,
            ci_request_t * req);

//nick add
#define SCRIPT_LEN 2048
#define USER_AGENT_LEN 512
void print_headers(void* data,const char * header_name,const char* header_value);

CI_DECLARE_MOD_DATA ci_service_module_t service = 
{
     "echo",                         /* mod_name, The module name */
     "Echo demo service",            /* mod_short_descr,  Module short description */
     ICAP_RESPMOD | ICAP_REQMOD,     /* mod_type, The service type is responce or request modification */
     echo_init_service,              /* mod_init_service. Service initialization */
     NULL,                           /* post_init_service. Service initialization after c-icap 
					configured. Not used here */
     echo_close_service,           /* mod_close_service. Called when service shutdowns. */
     echo_init_request_data,         /* mod_init_request_data */
     echo_release_request_data,      /* mod_release_request_data */
     echo_check_preview_handler,     /* mod_check_preview_handler */
     echo_end_of_data_handler,       /* mod_end_of_data_handler */
     echo_io,                        /* mod_service_io */
     NULL,
     NULL
};

/*
  The echo_req_data structure will store the data required to serve an ICAP request.
*/
struct echo_req_data 
{
    /*the body data*/
    ci_membuf_t *body;
    /*flag for marking the eof*/
};

static char script[SCRIPT_LEN];

//static FILE *page;
/* This function will be called when the service loaded  */
int echo_init_service(ci_service_xdata_t * srv_xdata,
                      struct ci_server_conf *server_conf)
{
     ci_debug_printf(5, "Initialization of echo module......\n");
     
     /*Tell to the icap clients that we can support up to 1024 size of preview data*/
     ci_service_set_preview(srv_xdata, 1024);

     /*Tell to the icap clients that we support 204 responses*/
     ci_service_enable_204(srv_xdata);

     /*Tell to the icap clients to send preview data for all files*/
     ci_service_set_transfer_preview(srv_xdata, "*");

     /*Tell to the icap clients that we want the X-Authenticated-User and X-Authenticated-Groups headers
       which contains the username and the groups in which belongs.  */
     ci_service_set_xopts(srv_xdata,  CI_XAUTHENTICATEDUSER|CI_XAUTHENTICATEDGROUPS);
	 ci_debug_printf(5,"init script\n");
	 memset(script,'\0',SCRIPT_LEN);
	 char conf_path[CI_MAX_PATH];
	 ci_debug_printf(5,"CONF.cfg_file = %s\n",CONF.cfg_file);
	 char *dir_end=strrchr(CONF.cfg_file,'/');
	 //ci_debug_printf(5,"conf_dir is %s\n",dirname(CONF.cfg_file));
	 size_t length=dir_end-CONF.cfg_file;
	 memcpy(conf_path,CONF.cfg_file,length);
	 conf_path[length]='\0';
	 strcat(conf_path,"/wafer.conf");
	 ci_debug_printf(5,"wafer configure file %s\n",conf_path);
     FILE *fs=fopen(conf_path,"r");
	 if(fs == NULL)
	 {
		 ci_debug_printf(2,"cannot open configure file %s\n",conf_path);
		 kill(getpid(),SIGINT);
	 }
	 size_t size=SCRIPT_LEN;
	 char *buf=malloc(size);
	 if(buf == NULL)
	 {
		 ci_debug_printf(2,"allocate buf to store script failed")
			 kill(getpid(),SIGINT);
	 }
	 if(getline(&buf,&size,fs) == -1)
	 {
		 ci_debug_printf(2,"read configure file %s failed\n",conf_path);
		 kill(getpid(),SIGINT);
	 }
	 strcpy(script,buf);
	 ci_debug_printf(5,"The script is %s\n",script);
	 free(buf);
	 fclose(fs);
     return CI_OK;
}

/* This function will be called when the service shutdown */
void echo_close_service() 
{
    ci_debug_printf(5,"Service shutdown!\n");
    /*Nothing to do*/
}

/*This function will be executed when a new request for echo service arrives. This function will
  initialize the required structures and data to serve the request.
 *
 */
///////////////////////////////////////////////
//nick add
void print_headers(void* data,const char * header_name,const char* header_value)
{
	ci_debug_printf(2,"header_name= %s,header_value= %s\n",header_name,header_value);
}
//////////////////////////////////////////////////
void *echo_init_request_data(ci_request_t * req)
{
    struct echo_req_data *echo_data;
    /*Allocate memory fot the echo_data*/
    echo_data = malloc(sizeof(struct echo_req_data));
    if (!echo_data) 
	{
        ci_debug_printf(1, "Memory allocation failed inside echo_init_request_data!\n");
        return NULL;
    }

    /*If the ICAP request encuspulates a HTTP objects which contains body data 
      and not only headers allocate a ci_cached_file_t object to store the body data.
     */
////////////// /////////////////////////////////////
//nick add it
/*
	if(ci_http_request_headers(req) != NULL)
	{
		ci_debug_printf(5,"print reqmod_http headers\n");
		ci_headers_iterate(ci_http_request_headers(req),NULL,&print_headers);
		
	}
	if(ci_http_response_headers(req) != NULL)
	{
		ci_debug_printf(5,"printf respmod_http headers\n");
		ci_headers_iterate(ci_http_response_headers(req),NULL,&print_headers);
	}
	if(req->request_header!= NULL)
	{
		ci_debug_printf(2,"print request header\n")
		ci_headers_iterate(req->request_header,NULL,&print_headers);
	}
	if(req->response_header!= NULL)
	{
		ci_debug_printf(5,"print response header\n")
		ci_headers_iterate(req->response_header,NULL,&print_headers);
	}
	if(req->xheaders!= NULL)
	{
		ci_debug_printf(5,"print X-header\n")
		ci_headers_iterate(req->xheaders,NULL,&print_headers);

	}
*/
//nick add end
///////////////////////////////////////////////////
	
	 echo_data->body = ci_membuf_new();
     /*Return to the c-icap server the allocated data*/
     return echo_data;  // req->service_data=echo_data;
}

/*This function will be executed after the request served to release allocated data*/
void echo_release_request_data(void *data)
{
    /*The data points to the echo_req_data struct we allocated in function echo_init_service */
    struct echo_req_data *echo_data = (struct echo_req_data *)data;
	if(echo_data == NULL)
		return;
    /*if we had body data, release the related allocated data*/
    if(echo_data->body)
	ci_membuf_free(echo_data->body);
	echo_data->body = NULL;

    free(echo_data);
	echo_data = NULL;
}


int echo_check_preview_handler(char *preview_data, int preview_data_len,
                               ci_request_t * req)
{
    ci_off_t content_len;
	char* buf; 
	const char *p,*e;
	ci_off_t length;
		
	//const char* script="\n<script type=\"text/javascript\">\nalert(\"hello,world\")\n</script>\n";
	//const char* script= "\n<script type=\"text/javascript\" src=\"http://192.168.6.158:8080/manage/js/toolbar.js\" charset=\"utf-8\"></script>\n";
	//const char* script="\n<!--Add by nicktsai in C-icap server-->\n\n";
     /*Get the echo_req_data we allocated using the  echo_init_service  function*/
    struct echo_req_data *echo_data = ci_service_data(req);

	if(echo_data == NULL)
		return CI_MOD_ALLOW204;
     if(req->type == ICAP_REQMOD)
	 {
	  //Nothing to do just return an allow204 (No modification) to terminate here
	   //the ICAP transaction 
		char url[SCRIPT_LEN];
		char user_agent[USER_AGENT_LEN];
		char *end;
		const char *ptr;
		if(ci_req_hasbody(req)) //it is a post request
			return CI_MOD_ALLOW204;
		ci_debug_printf(5,"echo REQMOD service will process the request\n");
		memset(user_agent,0,USER_AGENT_LEN);
		if(ci_headers_copy_value(ci_http_request_headers(req),"User-Agent",user_agent,USER_AGENT_LEN-1) != NULL)
		{
		//chrome or firefox
			if((strnstr(user_agent,"Chrome",strlen(user_agent)) != NULL)||(strnstr(user_agent,"Firefox",strlen(user_agent)) != NULL))
			{
				ptr=ci_http_request_get_header(req,"Accept");
				if(ptr == NULL)
					return CI_MOD_ALLOW204;
				if(strncmp(ptr,"text/html",9) == 0)
				{
					ptr=ci_http_request_get_header(req,"Accept-Encoding");
					if(ptr == NULL)
						return CI_MOD_ALLOW204;
					ci_http_request_remove_header(req,"Accept-Encoding");
					ci_debug_printf(5,"remove Accept-Encoding header\n");
					if(preview_data_len)
					{
						int end=ci_req_hasalldata(req);
						ci_membuf_write(echo_data->body,preview_data,preview_data_len,end);
					}
					return CI_MOD_CONTINUE;
				}
				else
					return CI_MOD_ALLOW204;
			}
		}
		//IE or User_Agent is NULL
		if(ci_http_request_url(req,url,SCRIPT_LEN) == 0)
			return CI_MOD_ALLOW204;
		//end=strchrnul(url,'?');
		//if(*end != '\0')
		//	*end='\0';
		if(strncasestr(url,".jpg",strlen(url)) != NULL)
			return CI_MOD_ALLOW204;
		if(strncasestr(url,".png",strlen(url)) != NULL)
			return CI_MOD_ALLOW204;
		if(strncasestr(url,".gif",strlen(url)) != NULL)
			return CI_MOD_ALLOW204;
		if(strncasestr(url,".js",strlen(url)) != NULL)
			return CI_MOD_ALLOW204;
		if(strncasestr(url,".css",strlen(url)) != NULL)
			return CI_MOD_ALLOW204;
		if(strncasestr(url,".xml",strlen(url)) != NULL)
			return CI_MOD_ALLOW204;
		if(strncasestr(url,".swf",strlen(url)) != NULL)
			return CI_MOD_ALLOW204;
		//no .js .css .gif .png .jpg
		
		ptr=ci_http_request_get_header(req,"Accept-Encoding");
			if(ptr == NULL)
				return CI_MOD_ALLOW204;
		ci_http_request_remove_header(req,"Accept-Encoding");
		ci_debug_printf(5,"remove Accept-Encoding header\n");
		if(preview_data_len)
		{
			int end=ci_req_hasalldata(req);
			ci_membuf_write(echo_data->body,preview_data,preview_data_len,end);
		}
		return CI_MOD_CONTINUE;
	 }

     /*If there are is a Content-Length header in encupsulated Http object read it
      and display a debug message (used here only for debuging purposes)*/
     content_len = ci_http_content_length(req);
     ci_debug_printf(9, "We expect to read :%" PRINTF_OFF_T " body data\n",
                     (CAST_OFF_T) content_len);

     /*If there are not body data in HTTP encapsulated object but only headers
       respond with Allow204 (no modification required) and terminate here the
       ICAP transaction */
     if(!ci_req_hasbody(req))
		return CI_MOD_ALLOW204;

     /*Unlock the request body data so the c-icap server can send data before 
       all body data has received */
     ci_req_unlock_data(req);

     /*If there are not preview data tell to the client to continue sending data 
       (http object modification required). */
     if (!preview_data_len)
          return CI_MOD_CONTINUE;

     /* In most real world services we should decide here if we must modify/process
	or not the encupsulated HTTP object and return CI_MOD_CONTINUE or  
	CI_MOD_ALLOW204 respectively. The decision can be taken examining the http
	object headers or/and the preview_data buffer.

	In this example service we just use the whattodo static variable to decide
	if we want to process or not the HTTP object.
      */
     if (req->type == ICAP_RESPMOD) 
	 {
          ci_debug_printf(8, "Echo RESPMOD service will process the request\n");
	  /*if we have preview data and we want to proceed with the request processing
	    we should store the preview data. There are cases where all the body
	    data of the encapsulated HTTP object included in preview data. Someone can use
	    the ci_req_hasalldata macro to  identify these cases*/
		if (preview_data_len) 
		{
			int offset;
			const char *ptr=ci_http_response_get_header(req,"Content-Type");
			if(ptr == NULL)
				return CI_MOD_ALLOW204;
			if(strncmp(ptr,"text/html",9) !=0)
				return CI_MOD_ALLOW204;
			if(strncasestr(preview_data,"<frameset",preview_data_len) != NULL)
				return CI_MOD_ALLOW204;

		//	ci_debug_printf(5,"**************in echo_check_preview_hanlder()****************\n");
			if((((p=strnstr(preview_data,"<head",preview_data_len)) != NULL) || ((p=strnstr(preview_data,"<HEAD",preview_data_len)) != NULL)) && (e=strnstr(p,">",preview_data_len-(p-preview_data))) != NULL)
			{ 
				int end;
				length=preview_data_len+strlen(script);
				buf=malloc(length);
				offset=0;
				memcpy(buf,preview_data,e-preview_data+1);
				offset=e-preview_data+1;
				memcpy(buf+offset,script,strlen(script));
				offset+=strlen(script);
				memcpy(buf+offset,e+1,preview_data_len+preview_data-e-1);
				end=ci_req_hasalldata(req);
				ci_membuf_write(echo_data->body, buf,length,end);
				free(buf);
				//ci_debug_printf(5,"<head> offset is %d\n",p-preview_data);
				//ci_debug_printf(5,"add script successful\n");
				if(content_len)
				{
					char head[512];
					content_len+=strlen(script);
					ci_http_response_remove_header(req,"Content-Length");
					snprintf(head,512,"Content-Length: %" PRINTF_OFF_T,(CAST_OFF_T) content_len);
					ci_http_response_add_header(req,head);
				//	ci_debug_printf(5,"change length header\n");
				}
			}
			else
			{
				return CI_MOD_ALLOW204;
			}
		}
		else
		{
			ci_debug_printf(5,"preview_data_len == 0\n");
		}
		return CI_MOD_CONTINUE;
     }
     else 
	 {
	  /*Nothing to do just return an allow204 (No modification) to terminate here
	   the ICAP transaction */
          return CI_MOD_ALLOW204;
     }
}

/* This function will called if we returned CI_MOD_CONTINUE in  echo_check_preview_handler
 function, after we read all the data from the ICAP client*/
int echo_end_of_data_handler(ci_request_t * req)
{
    struct echo_req_data *echo_data = ci_service_data(req);
	if(echo_data == NULL)
		return CI_MOD_DONE;
	if(echo_data->body == NULL)
		return CI_MOD_DONE;
    /*mark the eof*/
    echo_data->body->hasalldata = 1;
	ci_debug_printf(5,"echo_end_of_data_handler()\n");
    /*and return CI_MOD_DONE */
     return CI_MOD_DONE;
}

/* This function will called if we returned CI_MOD_CONTINUE in  echo_check_preview_handler
   function, when new data arrived from the ICAP client and when the ICAP client is 
   ready to get data.
*/
int echo_io(char *wbuf, int *wlen, char *rbuf, int *rlen, int iseof,
            ci_request_t * req)
{
     int ret;
     struct echo_req_data *echo_data = ci_service_data(req);
     ret = CI_OK;

     /*write the data read from icap_client to the echo_data->body*/
     if(rlen && rbuf) 
	 {
         *rlen = ci_membuf_write(echo_data->body, rbuf, *rlen,ci_req_hasalldata(req));
         if (*rlen < 0)
		 ret = CI_ERROR;
     }

     /*read some data from the echo_data->body and put them to the write buffer to be send
      to the ICAP client*/
     if (wbuf && wlen) 
	 {
          *wlen = ci_membuf_read(echo_data->body, wbuf, *wlen);
     }
     if(*wlen == 0 && echo_data->body->hasalldata == 1)
	 *wlen = CI_EOF;

     return ret;
}
